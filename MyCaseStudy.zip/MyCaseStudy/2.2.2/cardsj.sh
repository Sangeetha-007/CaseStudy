sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create card \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--query "select CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, TRANSACTION_VALUE, \
concat(lpad(year, 4, '0'), lpad(month, 2, '0'), lpad(day, 2, '0')) as TIMEID, \
last_updated, TRANSACTION_ID, TRANSACTION_TYPE from cdw_sapp_creditcard \
where \$CONDITIONS" \
--fields-terminated-by ',' \
--append \
--incremental lastmodified \
--check-column last_updated \
--target-dir /user/maria_dev/TESTING/Credit_Card_System/2.2.1/Data_Extraction_Module/Optimized/cdw_sapp_card \
-m 1 