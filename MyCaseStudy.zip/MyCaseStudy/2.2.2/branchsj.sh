sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create branch \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--query "select branch_code, \
branch_name, \
concat('(',right(branch_phone, 3), ')', mid(branch_phone, 4, 3), '-', right(branch_phone, 4)) \
as cust_phone , \
branch_street, \
branch_city, \
lpad(branch_zip, 5, '0'), \
last_updated, \
branch_state from cdw_sapp_branch \
where \$CONDITIONS" \
--fields-terminated-by ',' \
--append \
--incremental lastmodified \
--check-column last_updated \
--target-dir /user/maria_dev/TESTING/Credit_Card_System/2.2.1/Data_Extraction_Module/Optimized/cdw_sapp_branch \
-m 1