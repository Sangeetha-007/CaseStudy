sqoop job \
--meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create customer \
-- import \
--connect jdbc:mysql://localhost/cdw_sapp \
--driver com.mysql.jdbc.Driver \
--query "select ssn, concat(upper(substr(first_name, 1, 1)), lower(substr(first_name, 2))) \
as first_name, lower(MIDDLE_NAME) as middleName, concat(upper(substr(last_name,1,1)), \
lower(substr(last_name,2 ))) as last_name, credit_card_no, concat(street_name, ' ', apt_no) \
as cust_address, CUST_CITY, CUST_COUNTRY, cust_zip, concat('(',right(CUST_PHONE, 3), ')', mid(CUST_PHONE, 4, 3), '-', \
right(CUST_PHONE, 4)) as cust_phone, CUST_EMAIL, last_updated, CUST_STATE from cdw_sapp_customer \
where \$CONDITIONS" \
--fields-terminated-by ',' \
--append \
--incremental lastmodified \
--check-column last_updated \
--target-dir /user/maria_dev/TESTING/Credit_Card_System/2.2.1/Data_Extraction_Module/Optimized/cdw_sapp_customer \
-m 1